# tetris-brick-game
Tetris Brick game using basic Windows Form and C# Dotnet codes
